/*
 Navicat Premium Data Transfer

 Source Server         : 99.suyiiyii.top4000_tidb
 Source Server Type    : MySQL
 Source Server Version : 80011 (8.0.11-TiDB-v7.5.0)
 Source Host           : 10.21.22.41:4000
 Source Schema         : dinner

 Target Server Type    : MySQL
 Target Server Version : 80011 (8.0.11-TiDB-v7.5.0)
 File Encoding         : 65001

 Date: 05/06/2024 18:57:20
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for dish
-- ----------------------------
DROP TABLE IF EXISTS `dish`;
CREATE TABLE `dish`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `img_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `price` int(11) NULL DEFAULT NULL,
  `stock` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `name`(`name` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 30019 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dish
-- ----------------------------
INSERT INTO `dish` VALUES (1, '炸鸡1', '肯德基半成品汉堡胚面包胚子自制家用汉堡鸡排整箱商用营养早餐', '炸鸡', '1', 'https://s2.loli.net/2024/03/29/lIceQA3Fykw4TWx.jpg', 1111, 10644464);
INSERT INTO `dish` VALUES (2, '炸鸡2', '4斤奥尔良鸡翅中KFC口味腌制翅中商用半成品空气炸锅食材1斤批发', '炸鸡', '1', 'https://s2.loli.net/2024/03/29/YrRKP5246oFZ1gp.jpg', 2, 0);
INSERT INTO `dish` VALUES (3, '炸鸡3', '鸡腿新鲜鸡大腿琵毒腿单冻鸡腿生鲜肯德基腿优质批发跨境速卖通', '闸机', '1', 'https://s2.loli.net/2024/03/29/bYV9U8rATz3e5vg.jpg', 44, 125);
INSERT INTO `dish` VALUES (4, '炸鸡4', 'CP薯乐鸡块黑胡椒味900g 上校麦香鸡块KFC同款半成品油炸小吃', '闸机', '1', 'https://s2.loli.net/2024/03/29/z9ULgWd27HSJaV5.jpg', 25, 0);
INSERT INTO `dish` VALUES (5, '炸鸡5', '炸鸡半成品1kg香辣鸡腿脆皮翅根冷冻空气油炸锅小吃非肯德基', '炸机', '1', 'https://s2.loli.net/2024/03/29/Cpz9qQHX8Fc2Eng.jpg', 41, 4);
INSERT INTO `dish` VALUES (6, '炸鸡6', '肯德基口味香辣翅根鸡翅鸡肉类油炸半成品小吃小鸡腿翅膀鸡排批发', '炸机', '1', 'https://s2.loli.net/2024/03/29/P2Sb8cZFnVD7twg.jpg', 5, 133);
INSERT INTO `dish` VALUES (11, '海之蓝', '洋河 海之蓝 绵柔浓香型白酒 42度 480ml*2瓶 礼盒装 ', '酒品', '1', 'https://img12.360buyimg.com/n1/jfs/t1/95107/38/9362/315281/5e0eb51fE08ce1de6/db8d7d4fab9fd2e0.jpg.avif', 338, 999);
INSERT INTO `dish` VALUES (13, '奥利给', '干就完事了！！奥利给！！！！', '美食', NULL, 'https://picx.zhimg.com/70/v2-6286d61161f41e67dd1956e2e30bd163_1440w.avis?source=172ae18b&biz_tag=Post', 666, 993);
INSERT INTO `dish` VALUES (14, '红星白酒', '红星白酒 绿瓶清香型 纯粮酒固态发酵 高度口粮酒 北京怀柔总厂 56度 100mL 1瓶 ', '酒品', NULL, 'https://img14.360buyimg.com/n0/jfs/t1/128979/18/33692/62126/64d32917F77472274/c461adaf58d9bdd5.jpg.avif', 7, 97);
INSERT INTO `dish` VALUES (16, '茅台', '茅台（MOUTAI）2023年 飞天 酱香型白酒 53度 500ml 单瓶装 ', '酒品', NULL, 'https://img14.360buyimg.com/n0/jfs/t1/33800/6/19988/140008/63f7140bF76016542/ff9ad35506ddaa55.jpg.avif', 2799, 5);
INSERT INTO `dish` VALUES (17, '秘制小汉堡', '老八秘制小汉堡 奥利给，造它就完了！！', '美食', NULL, 'https://syimg.3dmgame.com/uploadimg/upload/image/20200526/20200526175701_56087.jpg', 6, 664);
INSERT INTO `dish` VALUES (18, '九转大肠', '我去除了大部分的肠的腥味，但是我保留了一部分，我觉得保留了一部分肠的味道才知道你吃的是大肠。', '美食', NULL, 'https://i3.meishichina.com/atta/recipe/2011/12/04/201112041152225.jpg?x-oss-process=style/p800', 8, 888);

-- ----------------------------
-- Table structure for order
-- ----------------------------
DROP TABLE IF EXISTS `order`;
CREATE TABLE `order`  (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NULL DEFAULT NULL,
  `table_id` int(11) NULL DEFAULT NULL,
  `status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `total_price` int(11) NULL DEFAULT NULL,
  `created_at` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`order_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 30129 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of order
-- ----------------------------
INSERT INTO `order` VALUES (21, 38, 8, 'unpaid', 0, 1711799634);
INSERT INTO `order` VALUES (22, 36, 7, 'unpaid', 0, 1711799711);
INSERT INTO `order` VALUES (23, 36, 7, 'unpaid', 0, 1711815271);
INSERT INTO `order` VALUES (24, 36, 1, 'unpaid', 0, 1711816587);
INSERT INTO `order` VALUES (25, 36, 1, 'unpaid', 0, 1711816774);
INSERT INTO `order` VALUES (26, 36, 1, 'unpaid', 0, 1711816807);
INSERT INTO `order` VALUES (27, 36, 1, 'unpaid', 0, 1711816886);
INSERT INTO `order` VALUES (29, 36, 1, 'unpaid', 99990, 1711817064);
INSERT INTO `order` VALUES (30, 36, 7, 'unpaid', 28, 1711898823);
INSERT INTO `order` VALUES (31, 30, 2, 'unpaid', 12, 1711973552);
INSERT INTO `order` VALUES (32, 36, 19, 'unpaid', 3766, 1712030193);
INSERT INTO `order` VALUES (33, 41, 7, 'unpaid', 71, 1712031088);
INSERT INTO `order` VALUES (34, 38, 8, 'unpaid', 0, 1712654479);
INSERT INTO `order` VALUES (35, 38, 8, 'unpaid', 2060, 1712654486);
INSERT INTO `order` VALUES (36, 38, 8, 'unpaid', 2060, 1712654499);
INSERT INTO `order` VALUES (39, 38, 8, 'unpaid', 0, 1712654515);
INSERT INTO `order` VALUES (40, 38, 8, 'unpaid', 0, 1712654518);
INSERT INTO `order` VALUES (41, 38, 8, 'unpaid', 0, 1712654527);
INSERT INTO `order` VALUES (42, 38, 8, 'unpaid', 0, 1712654605);
INSERT INTO `order` VALUES (43, 38, 8, 'unpaid', 0, 1712654605);
INSERT INTO `order` VALUES (44, 38, 8, 'unpaid', 0, 1712654606);
INSERT INTO `order` VALUES (46, 38, 8, 'unpaid', 0, 1712655055);
INSERT INTO `order` VALUES (47, 38, 8, 'unpaid', 0, 1712655061);
INSERT INTO `order` VALUES (48, 38, 8, 'unpaid', 0, 1712655063);
INSERT INTO `order` VALUES (49, 38, 8, 'unpaid', 0, 1712655066);
INSERT INTO `order` VALUES (50, 38, 8, 'unpaid', 0, 1712655068);
INSERT INTO `order` VALUES (51, 38, 8, 'unpaid', 0, 1712655070);
INSERT INTO `order` VALUES (52, 38, 8, 'unpaid', 0, 1712655087);
INSERT INTO `order` VALUES (53, 38, 8, 'unpaid', 0, 1712655088);
INSERT INTO `order` VALUES (54, 38, 8, 'unpaid', 0, 1712655091);
INSERT INTO `order` VALUES (55, 38, 8, 'unpaid', 0, 1712655092);
INSERT INTO `order` VALUES (56, 38, 8, 'unpaid', 0, 1712655094);
INSERT INTO `order` VALUES (57, 38, 8, 'unpaid', 0, 1712655095);
INSERT INTO `order` VALUES (58, 38, 8, 'unpaid', 0, 1712655107);
INSERT INTO `order` VALUES (59, 38, 8, 'unpaid', 0, 1712655108);
INSERT INTO `order` VALUES (60, 38, 8, 'unpaid', 0, 1712655108);
INSERT INTO `order` VALUES (61, 38, 8, 'unpaid', 0, 1712655108);
INSERT INTO `order` VALUES (63, 38, 8, 'unpaid', 0, 1712655109);
INSERT INTO `order` VALUES (64, 38, 8, 'unpaid', 0, 1712655110);
INSERT INTO `order` VALUES (65, 38, 8, 'unpaid', 0, 1712655111);
INSERT INTO `order` VALUES (66, 38, 8, 'unpaid', 0, 1712655112);
INSERT INTO `order` VALUES (67, 38, 8, 'unpaid', 0, 1712655114);
INSERT INTO `order` VALUES (68, 38, 8, 'unpaid', 0, 1712655115);
INSERT INTO `order` VALUES (69, 38, 8, 'unpaid', 0, 1712655115);
INSERT INTO `order` VALUES (70, 38, 8, 'unpaid', 0, 1712655116);
INSERT INTO `order` VALUES (71, 38, 8, 'unpaid', 0, 1712655118);
INSERT INTO `order` VALUES (72, 38, 8, 'unpaid', 0, 1712655119);
INSERT INTO `order` VALUES (73, 38, 8, 'unpaid', 0, 1712655120);
INSERT INTO `order` VALUES (74, 38, 8, 'unpaid', 0, 1712655120);
INSERT INTO `order` VALUES (75, 38, 8, 'unpaid', 0, 1712655120);
INSERT INTO `order` VALUES (76, 38, 8, 'unpaid', 0, 1712655122);
INSERT INTO `order` VALUES (77, 38, 8, 'unpaid', 0, 1712655122);
INSERT INTO `order` VALUES (78, 38, 8, 'unpaid', 0, 1712655123);
INSERT INTO `order` VALUES (79, 38, 8, 'unpaid', 0, 1712655123);
INSERT INTO `order` VALUES (80, 38, 8, 'unpaid', 0, 1712655124);
INSERT INTO `order` VALUES (81, 38, 8, 'unpaid', 0, 1712655125);
INSERT INTO `order` VALUES (82, 38, 8, 'unpaid', 0, 1712655126);
INSERT INTO `order` VALUES (83, 38, 8, 'unpaid', 0, 1712655126);
INSERT INTO `order` VALUES (84, 38, 8, 'unpaid', 0, 1712655127);
INSERT INTO `order` VALUES (85, 38, 8, 'unpaid', 0, 1712655127);
INSERT INTO `order` VALUES (86, 38, 8, 'unpaid', 0, 1712655128);
INSERT INTO `order` VALUES (87, 38, 8, 'unpaid', 0, 1712655129);
INSERT INTO `order` VALUES (88, 38, 8, 'unpaid', 0, 1712655130);
INSERT INTO `order` VALUES (89, 38, 8, 'unpaid', 0, 1712655371);
INSERT INTO `order` VALUES (90, 38, 8, 'unpaid', 0, 1712655377);
INSERT INTO `order` VALUES (91, 38, 8, 'unpaid', 0, 1712655379);
INSERT INTO `order` VALUES (92, 38, 8, 'unpaid', 0, 1712655379);
INSERT INTO `order` VALUES (93, 38, 8, 'unpaid', 0, 1712655379);
INSERT INTO `order` VALUES (94, 38, 8, 'unpaid', 0, 1712655599);
INSERT INTO `order` VALUES (95, 38, 8, 'unpaid', 0, 1712655603);
INSERT INTO `order` VALUES (96, 38, 8, 'unpaid', 0, 1712655611);
INSERT INTO `order` VALUES (97, 38, 8, 'unpaid', 0, 1712655624);
INSERT INTO `order` VALUES (98, 38, 8, 'unpaid', 0, 1712655626);
INSERT INTO `order` VALUES (99, 38, 8, 'unpaid', 0, 1712655628);
INSERT INTO `order` VALUES (100, 38, 8, 'unpaid', 0, 1712655629);
INSERT INTO `order` VALUES (101, 38, 8, 'unpaid', 0, 1712655630);
INSERT INTO `order` VALUES (102, 38, 8, 'unpaid', 0, 1712655632);
INSERT INTO `order` VALUES (103, 38, 8, 'unpaid', 0, 1712655633);
INSERT INTO `order` VALUES (104, 38, 8, 'unpaid', 0, 1712655635);
INSERT INTO `order` VALUES (105, 38, 8, 'unpaid', 0, 1712655636);
INSERT INTO `order` VALUES (106, 38, 8, 'unpaid', 0, 1712655637);
INSERT INTO `order` VALUES (107, 38, 8, 'unpaid', 0, 1712655638);
INSERT INTO `order` VALUES (108, 38, 8, 'unpaid', 0, 1712655639);
INSERT INTO `order` VALUES (109, 38, 8, 'unpaid', 0, 1712655641);
INSERT INTO `order` VALUES (110, 38, 8, 'unpaid', 0, 1712655642);
INSERT INTO `order` VALUES (111, 38, 8, 'unpaid', 0, 1712655643);
INSERT INTO `order` VALUES (112, 38, 8, 'unpaid', 0, 1712655645);
INSERT INTO `order` VALUES (113, 38, 8, 'unpaid', 0, 1712655646);
INSERT INTO `order` VALUES (114, 38, 8, 'unpaid', 0, 1712655647);
INSERT INTO `order` VALUES (115, 38, 8, 'unpaid', 0, 1712655648);
INSERT INTO `order` VALUES (116, 38, 8, 'unpaid', 0, 1712655650);
INSERT INTO `order` VALUES (117, 38, 8, 'unpaid', 0, 1712656083);
INSERT INTO `order` VALUES (118, 38, 8, 'unpaid', 0, 1712656091);
INSERT INTO `order` VALUES (119, 32, 2, 'unpaid', 5555, 1714744330);
INSERT INTO `order` VALUES (120, 38, 8, 'unpaid', 481, 1714797378);
INSERT INTO `order` VALUES (121, 32, 2, 'unpaid', 6, 1714811195);
INSERT INTO `order` VALUES (124, 32, 2, 'unpaid', 25, 1714960314);
INSERT INTO `order` VALUES (125, 32, 2, 'unpaid', 2, 1714960323);
INSERT INTO `order` VALUES (126, 32, 2, 'unpaid', 1111, 1714960345);
INSERT INTO `order` VALUES (127, 32, 2, 'unpaid', 1111, 1714967530);
INSERT INTO `order` VALUES (128, 32, 2, 'unpaid', 7, 1714980517);
INSERT INTO `order` VALUES (129, 32, 2, 'unpaid', 666, 1714996949);
INSERT INTO `order` VALUES (130, 32, 2, 'unpaid', 7, 1714999432);
INSERT INTO `order` VALUES (131, 32, 2, 'unpaid', 7, 1714999440);

-- ----------------------------
-- Table structure for order_item
-- ----------------------------
DROP TABLE IF EXISTS `order_item`;
CREATE TABLE `order_item`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NULL DEFAULT NULL,
  `dish_id` int(11) NULL DEFAULT NULL,
  `quantity` int(11) NULL DEFAULT NULL,
  `price` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 30412 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of order_item
-- ----------------------------
INSERT INTO `order_item` VALUES (46, 21, 1, 7, 11);
INSERT INTO `order_item` VALUES (47, 21, 5, 9, 41);
INSERT INTO `order_item` VALUES (48, 22, 1, 6, 11);
INSERT INTO `order_item` VALUES (49, 22, 3, 11, 44);
INSERT INTO `order_item` VALUES (50, 23, 1, 8, 1111);
INSERT INTO `order_item` VALUES (51, 23, 2, 7, 2);
INSERT INTO `order_item` VALUES (52, 23, 4, 6, 25);
INSERT INTO `order_item` VALUES (53, 23, 16, 3, 2799);
INSERT INTO `order_item` VALUES (54, 24, 5, 1, 41);
INSERT INTO `order_item` VALUES (55, 24, 6, 7, 5);
INSERT INTO `order_item` VALUES (56, 25, 1, 11, 1111);
INSERT INTO `order_item` VALUES (57, 26, 1, 6, 1111);
INSERT INTO `order_item` VALUES (58, 27, 1, 10, 1111);
INSERT INTO `order_item` VALUES (60, 29, 1, 90, 1111);
INSERT INTO `order_item` VALUES (61, 30, 2, 14, 2);
INSERT INTO `order_item` VALUES (62, 31, 17, 2, 6);
INSERT INTO `order_item` VALUES (63, 32, 2, 4, 2);
INSERT INTO `order_item` VALUES (64, 32, 3, 6, 44);
INSERT INTO `order_item` VALUES (65, 32, 5, 4, 41);
INSERT INTO `order_item` VALUES (66, 32, 13, 5, 666);
INSERT INTO `order_item` VALUES (67, 33, 2, 1, 2);
INSERT INTO `order_item` VALUES (68, 33, 3, 1, 44);
INSERT INTO `order_item` VALUES (69, 33, 4, 1, 25);
INSERT INTO `order_item` VALUES (70, 34, 2, 4, 2);
INSERT INTO `order_item` VALUES (71, 34, 4, 5, 25);
INSERT INTO `order_item` VALUES (72, 34, 3, 1000, 44);
INSERT INTO `order_item` VALUES (73, 35, 2, 4, 2);
INSERT INTO `order_item` VALUES (74, 35, 4, 5, 25);
INSERT INTO `order_item` VALUES (75, 35, 3, 0, 44);
INSERT INTO `order_item` VALUES (76, 35, 5, 47, 41);
INSERT INTO `order_item` VALUES (77, 36, 2, 4, 2);
INSERT INTO `order_item` VALUES (78, 36, 4, 5, 25);
INSERT INTO `order_item` VALUES (79, 36, 3, 0, 44);
INSERT INTO `order_item` VALUES (80, 36, 5, 47, 41);
INSERT INTO `order_item` VALUES (85, 39, 2, 0, 2);
INSERT INTO `order_item` VALUES (86, 39, 4, 0, 25);
INSERT INTO `order_item` VALUES (87, 39, 3, 0, 44);
INSERT INTO `order_item` VALUES (88, 39, 5, 0, 41);
INSERT INTO `order_item` VALUES (89, 40, 2, 0, 2);
INSERT INTO `order_item` VALUES (90, 40, 4, 0, 25);
INSERT INTO `order_item` VALUES (91, 40, 3, 0, 44);
INSERT INTO `order_item` VALUES (92, 40, 5, 0, 41);
INSERT INTO `order_item` VALUES (93, 41, 2, 0, 2);
INSERT INTO `order_item` VALUES (94, 41, 4, 0, 25);
INSERT INTO `order_item` VALUES (95, 41, 3, 0, 44);
INSERT INTO `order_item` VALUES (96, 41, 5, 0, 41);
INSERT INTO `order_item` VALUES (97, 42, 2, 0, 2);
INSERT INTO `order_item` VALUES (98, 42, 4, 0, 25);
INSERT INTO `order_item` VALUES (99, 42, 3, 0, 44);
INSERT INTO `order_item` VALUES (100, 42, 5, 0, 41);
INSERT INTO `order_item` VALUES (101, 42, 2, 0, 2);
INSERT INTO `order_item` VALUES (102, 42, 4, 0, 25);
INSERT INTO `order_item` VALUES (103, 42, 3, 0, 44);
INSERT INTO `order_item` VALUES (104, 42, 5, 0, 41);
INSERT INTO `order_item` VALUES (105, 44, 2, 0, 2);
INSERT INTO `order_item` VALUES (106, 44, 4, 0, 25);
INSERT INTO `order_item` VALUES (107, 44, 3, 0, 44);
INSERT INTO `order_item` VALUES (108, 44, 5, 0, 41);
INSERT INTO `order_item` VALUES (109, 46, 2, 0, 2);
INSERT INTO `order_item` VALUES (110, 46, 4, 0, 25);
INSERT INTO `order_item` VALUES (111, 46, 3, 0, 44);
INSERT INTO `order_item` VALUES (112, 46, 5, 0, 41);
INSERT INTO `order_item` VALUES (113, 47, 2, 0, 2);
INSERT INTO `order_item` VALUES (114, 47, 4, 0, 25);
INSERT INTO `order_item` VALUES (115, 47, 3, 0, 44);
INSERT INTO `order_item` VALUES (116, 47, 5, 0, 41);
INSERT INTO `order_item` VALUES (117, 48, 2, 0, 2);
INSERT INTO `order_item` VALUES (118, 48, 4, 0, 25);
INSERT INTO `order_item` VALUES (119, 48, 3, 0, 44);
INSERT INTO `order_item` VALUES (120, 48, 5, 0, 41);
INSERT INTO `order_item` VALUES (121, 49, 2, 0, 2);
INSERT INTO `order_item` VALUES (122, 49, 4, 0, 25);
INSERT INTO `order_item` VALUES (123, 49, 3, 0, 44);
INSERT INTO `order_item` VALUES (124, 49, 5, 0, 41);
INSERT INTO `order_item` VALUES (125, 50, 2, 0, 2);
INSERT INTO `order_item` VALUES (126, 50, 4, 0, 25);
INSERT INTO `order_item` VALUES (127, 50, 3, 0, 44);
INSERT INTO `order_item` VALUES (128, 50, 5, 0, 41);
INSERT INTO `order_item` VALUES (129, 51, 2, 0, 2);
INSERT INTO `order_item` VALUES (130, 51, 4, 0, 25);
INSERT INTO `order_item` VALUES (131, 51, 3, 0, 44);
INSERT INTO `order_item` VALUES (132, 51, 5, 0, 41);
INSERT INTO `order_item` VALUES (133, 52, 2, 0, 2);
INSERT INTO `order_item` VALUES (134, 52, 4, 0, 25);
INSERT INTO `order_item` VALUES (135, 52, 3, 0, 44);
INSERT INTO `order_item` VALUES (136, 52, 5, 0, 41);
INSERT INTO `order_item` VALUES (137, 53, 2, 0, 2);
INSERT INTO `order_item` VALUES (138, 53, 4, 0, 25);
INSERT INTO `order_item` VALUES (139, 53, 3, 0, 44);
INSERT INTO `order_item` VALUES (140, 53, 5, 0, 41);
INSERT INTO `order_item` VALUES (141, 54, 2, 0, 2);
INSERT INTO `order_item` VALUES (142, 54, 4, 0, 25);
INSERT INTO `order_item` VALUES (143, 54, 3, 0, 44);
INSERT INTO `order_item` VALUES (144, 54, 5, 0, 41);
INSERT INTO `order_item` VALUES (145, 55, 2, 0, 2);
INSERT INTO `order_item` VALUES (146, 55, 4, 0, 25);
INSERT INTO `order_item` VALUES (147, 55, 3, 0, 44);
INSERT INTO `order_item` VALUES (148, 55, 5, 0, 41);
INSERT INTO `order_item` VALUES (149, 56, 2, 0, 2);
INSERT INTO `order_item` VALUES (150, 56, 4, 0, 25);
INSERT INTO `order_item` VALUES (151, 56, 3, 0, 44);
INSERT INTO `order_item` VALUES (152, 56, 5, 0, 41);
INSERT INTO `order_item` VALUES (153, 57, 2, 0, 2);
INSERT INTO `order_item` VALUES (154, 57, 4, 0, 25);
INSERT INTO `order_item` VALUES (155, 57, 3, 0, 44);
INSERT INTO `order_item` VALUES (156, 57, 5, 0, 41);
INSERT INTO `order_item` VALUES (157, 58, 2, 0, 2);
INSERT INTO `order_item` VALUES (158, 58, 4, 0, 25);
INSERT INTO `order_item` VALUES (159, 58, 3, 0, 44);
INSERT INTO `order_item` VALUES (160, 58, 5, 0, 41);
INSERT INTO `order_item` VALUES (161, 59, 2, 0, 2);
INSERT INTO `order_item` VALUES (162, 59, 4, 0, 25);
INSERT INTO `order_item` VALUES (163, 59, 3, 0, 44);
INSERT INTO `order_item` VALUES (164, 59, 5, 0, 41);
INSERT INTO `order_item` VALUES (165, 59, 2, 0, 2);
INSERT INTO `order_item` VALUES (166, 59, 4, 0, 25);
INSERT INTO `order_item` VALUES (167, 59, 3, 0, 44);
INSERT INTO `order_item` VALUES (168, 59, 5, 0, 41);
INSERT INTO `order_item` VALUES (169, 59, 2, 0, 2);
INSERT INTO `order_item` VALUES (170, 59, 4, 0, 25);
INSERT INTO `order_item` VALUES (171, 59, 3, 0, 44);
INSERT INTO `order_item` VALUES (172, 59, 5, 0, 41);
INSERT INTO `order_item` VALUES (177, 63, 2, 0, 2);
INSERT INTO `order_item` VALUES (178, 63, 4, 0, 25);
INSERT INTO `order_item` VALUES (179, 63, 3, 0, 44);
INSERT INTO `order_item` VALUES (180, 63, 5, 0, 41);
INSERT INTO `order_item` VALUES (181, 64, 2, 0, 2);
INSERT INTO `order_item` VALUES (182, 64, 4, 0, 25);
INSERT INTO `order_item` VALUES (183, 64, 3, 0, 44);
INSERT INTO `order_item` VALUES (184, 64, 5, 0, 41);
INSERT INTO `order_item` VALUES (185, 65, 2, 0, 2);
INSERT INTO `order_item` VALUES (186, 65, 4, 0, 25);
INSERT INTO `order_item` VALUES (187, 65, 3, 0, 44);
INSERT INTO `order_item` VALUES (188, 65, 5, 0, 41);
INSERT INTO `order_item` VALUES (189, 66, 2, 0, 2);
INSERT INTO `order_item` VALUES (190, 66, 4, 0, 25);
INSERT INTO `order_item` VALUES (191, 66, 3, 0, 44);
INSERT INTO `order_item` VALUES (192, 66, 5, 0, 41);
INSERT INTO `order_item` VALUES (193, 67, 2, 0, 2);
INSERT INTO `order_item` VALUES (194, 67, 4, 0, 25);
INSERT INTO `order_item` VALUES (195, 67, 3, 0, 44);
INSERT INTO `order_item` VALUES (196, 67, 5, 0, 41);
INSERT INTO `order_item` VALUES (197, 68, 2, 0, 2);
INSERT INTO `order_item` VALUES (198, 68, 4, 0, 25);
INSERT INTO `order_item` VALUES (199, 68, 3, 0, 44);
INSERT INTO `order_item` VALUES (200, 68, 5, 0, 41);
INSERT INTO `order_item` VALUES (201, 68, 2, 0, 2);
INSERT INTO `order_item` VALUES (202, 68, 4, 0, 25);
INSERT INTO `order_item` VALUES (203, 68, 3, 0, 44);
INSERT INTO `order_item` VALUES (204, 68, 5, 0, 41);
INSERT INTO `order_item` VALUES (205, 70, 2, 0, 2);
INSERT INTO `order_item` VALUES (206, 70, 4, 0, 25);
INSERT INTO `order_item` VALUES (207, 70, 3, 0, 44);
INSERT INTO `order_item` VALUES (208, 70, 5, 0, 41);
INSERT INTO `order_item` VALUES (209, 71, 2, 0, 2);
INSERT INTO `order_item` VALUES (210, 71, 4, 0, 25);
INSERT INTO `order_item` VALUES (211, 71, 3, 0, 44);
INSERT INTO `order_item` VALUES (212, 71, 5, 0, 41);
INSERT INTO `order_item` VALUES (213, 72, 2, 0, 2);
INSERT INTO `order_item` VALUES (214, 72, 4, 0, 25);
INSERT INTO `order_item` VALUES (215, 72, 3, 0, 44);
INSERT INTO `order_item` VALUES (216, 72, 5, 0, 41);
INSERT INTO `order_item` VALUES (217, 73, 2, 0, 2);
INSERT INTO `order_item` VALUES (218, 73, 4, 0, 25);
INSERT INTO `order_item` VALUES (219, 73, 3, 0, 44);
INSERT INTO `order_item` VALUES (220, 73, 5, 0, 41);
INSERT INTO `order_item` VALUES (221, 73, 2, 0, 2);
INSERT INTO `order_item` VALUES (222, 73, 4, 0, 25);
INSERT INTO `order_item` VALUES (223, 73, 3, 0, 44);
INSERT INTO `order_item` VALUES (224, 73, 5, 0, 41);
INSERT INTO `order_item` VALUES (225, 73, 2, 0, 2);
INSERT INTO `order_item` VALUES (226, 73, 4, 0, 25);
INSERT INTO `order_item` VALUES (227, 73, 3, 0, 44);
INSERT INTO `order_item` VALUES (228, 73, 5, 0, 41);
INSERT INTO `order_item` VALUES (229, 76, 2, 0, 2);
INSERT INTO `order_item` VALUES (230, 76, 4, 0, 25);
INSERT INTO `order_item` VALUES (231, 76, 3, 0, 44);
INSERT INTO `order_item` VALUES (232, 76, 5, 0, 41);
INSERT INTO `order_item` VALUES (233, 76, 2, 0, 2);
INSERT INTO `order_item` VALUES (234, 76, 4, 0, 25);
INSERT INTO `order_item` VALUES (235, 76, 3, 0, 44);
INSERT INTO `order_item` VALUES (236, 76, 5, 0, 41);
INSERT INTO `order_item` VALUES (237, 78, 2, 0, 2);
INSERT INTO `order_item` VALUES (238, 78, 4, 0, 25);
INSERT INTO `order_item` VALUES (239, 78, 3, 0, 44);
INSERT INTO `order_item` VALUES (240, 78, 5, 0, 41);
INSERT INTO `order_item` VALUES (241, 78, 2, 0, 2);
INSERT INTO `order_item` VALUES (242, 78, 4, 0, 25);
INSERT INTO `order_item` VALUES (243, 78, 3, 0, 44);
INSERT INTO `order_item` VALUES (244, 78, 5, 0, 41);
INSERT INTO `order_item` VALUES (245, 80, 2, 0, 2);
INSERT INTO `order_item` VALUES (246, 80, 4, 0, 25);
INSERT INTO `order_item` VALUES (247, 80, 3, 0, 44);
INSERT INTO `order_item` VALUES (248, 80, 5, 0, 41);
INSERT INTO `order_item` VALUES (249, 81, 2, 0, 2);
INSERT INTO `order_item` VALUES (250, 81, 4, 0, 25);
INSERT INTO `order_item` VALUES (251, 81, 3, 0, 44);
INSERT INTO `order_item` VALUES (252, 81, 5, 0, 41);
INSERT INTO `order_item` VALUES (253, 82, 2, 0, 2);
INSERT INTO `order_item` VALUES (254, 82, 4, 0, 25);
INSERT INTO `order_item` VALUES (255, 82, 3, 0, 44);
INSERT INTO `order_item` VALUES (256, 82, 5, 0, 41);
INSERT INTO `order_item` VALUES (257, 82, 2, 0, 2);
INSERT INTO `order_item` VALUES (258, 82, 4, 0, 25);
INSERT INTO `order_item` VALUES (259, 82, 3, 0, 44);
INSERT INTO `order_item` VALUES (260, 82, 5, 0, 41);
INSERT INTO `order_item` VALUES (261, 84, 2, 0, 2);
INSERT INTO `order_item` VALUES (262, 84, 4, 0, 25);
INSERT INTO `order_item` VALUES (263, 84, 3, 0, 44);
INSERT INTO `order_item` VALUES (264, 84, 5, 0, 41);
INSERT INTO `order_item` VALUES (265, 84, 2, 0, 2);
INSERT INTO `order_item` VALUES (266, 84, 4, 0, 25);
INSERT INTO `order_item` VALUES (267, 84, 3, 0, 44);
INSERT INTO `order_item` VALUES (268, 84, 5, 0, 41);
INSERT INTO `order_item` VALUES (269, 86, 2, 0, 2);
INSERT INTO `order_item` VALUES (270, 86, 4, 0, 25);
INSERT INTO `order_item` VALUES (271, 86, 3, 0, 44);
INSERT INTO `order_item` VALUES (272, 86, 5, 0, 41);
INSERT INTO `order_item` VALUES (273, 87, 2, 0, 2);
INSERT INTO `order_item` VALUES (274, 87, 4, 0, 25);
INSERT INTO `order_item` VALUES (275, 87, 3, 0, 44);
INSERT INTO `order_item` VALUES (276, 87, 5, 0, 41);
INSERT INTO `order_item` VALUES (277, 88, 2, 0, 2);
INSERT INTO `order_item` VALUES (278, 88, 4, 0, 25);
INSERT INTO `order_item` VALUES (279, 88, 3, 0, 44);
INSERT INTO `order_item` VALUES (280, 88, 5, 0, 41);
INSERT INTO `order_item` VALUES (281, 89, 2, 0, 2);
INSERT INTO `order_item` VALUES (282, 89, 4, 0, 25);
INSERT INTO `order_item` VALUES (283, 89, 3, 0, 44);
INSERT INTO `order_item` VALUES (284, 89, 5, 0, 41);
INSERT INTO `order_item` VALUES (285, 90, 2, 0, 2);
INSERT INTO `order_item` VALUES (286, 90, 4, 0, 25);
INSERT INTO `order_item` VALUES (287, 90, 3, 0, 44);
INSERT INTO `order_item` VALUES (288, 90, 5, 0, 41);
INSERT INTO `order_item` VALUES (289, 91, 2, 0, 2);
INSERT INTO `order_item` VALUES (290, 91, 4, 0, 25);
INSERT INTO `order_item` VALUES (291, 91, 3, 0, 44);
INSERT INTO `order_item` VALUES (292, 91, 5, 0, 41);
INSERT INTO `order_item` VALUES (293, 91, 2, 0, 2);
INSERT INTO `order_item` VALUES (294, 91, 4, 0, 25);
INSERT INTO `order_item` VALUES (295, 91, 3, 0, 44);
INSERT INTO `order_item` VALUES (296, 91, 5, 0, 41);
INSERT INTO `order_item` VALUES (297, 91, 2, 0, 2);
INSERT INTO `order_item` VALUES (298, 91, 4, 0, 25);
INSERT INTO `order_item` VALUES (299, 91, 3, 0, 44);
INSERT INTO `order_item` VALUES (300, 91, 5, 0, 41);
INSERT INTO `order_item` VALUES (301, 94, 2, 0, 2);
INSERT INTO `order_item` VALUES (302, 94, 4, 0, 25);
INSERT INTO `order_item` VALUES (303, 94, 3, 0, 44);
INSERT INTO `order_item` VALUES (304, 94, 5, 0, 41);
INSERT INTO `order_item` VALUES (305, 95, 2, 0, 2);
INSERT INTO `order_item` VALUES (306, 95, 4, 0, 25);
INSERT INTO `order_item` VALUES (307, 95, 3, 0, 44);
INSERT INTO `order_item` VALUES (308, 95, 5, 0, 41);
INSERT INTO `order_item` VALUES (309, 96, 2, 0, 2);
INSERT INTO `order_item` VALUES (310, 96, 4, 0, 25);
INSERT INTO `order_item` VALUES (311, 96, 3, 0, 44);
INSERT INTO `order_item` VALUES (312, 96, 5, 0, 41);
INSERT INTO `order_item` VALUES (313, 97, 2, 0, 2);
INSERT INTO `order_item` VALUES (314, 97, 4, 0, 25);
INSERT INTO `order_item` VALUES (315, 97, 3, 0, 44);
INSERT INTO `order_item` VALUES (316, 97, 5, 0, 41);
INSERT INTO `order_item` VALUES (317, 98, 2, 0, 2);
INSERT INTO `order_item` VALUES (318, 98, 4, 0, 25);
INSERT INTO `order_item` VALUES (319, 98, 3, 0, 44);
INSERT INTO `order_item` VALUES (320, 98, 5, 0, 41);
INSERT INTO `order_item` VALUES (321, 99, 2, 0, 2);
INSERT INTO `order_item` VALUES (322, 99, 4, 0, 25);
INSERT INTO `order_item` VALUES (323, 99, 3, 0, 44);
INSERT INTO `order_item` VALUES (324, 99, 5, 0, 41);
INSERT INTO `order_item` VALUES (325, 100, 2, 0, 2);
INSERT INTO `order_item` VALUES (326, 100, 4, 0, 25);
INSERT INTO `order_item` VALUES (327, 100, 3, 0, 44);
INSERT INTO `order_item` VALUES (328, 100, 5, 0, 41);
INSERT INTO `order_item` VALUES (329, 101, 2, 0, 2);
INSERT INTO `order_item` VALUES (330, 101, 4, 0, 25);
INSERT INTO `order_item` VALUES (331, 101, 3, 0, 44);
INSERT INTO `order_item` VALUES (332, 101, 5, 0, 41);
INSERT INTO `order_item` VALUES (333, 102, 2, 0, 2);
INSERT INTO `order_item` VALUES (334, 102, 4, 0, 25);
INSERT INTO `order_item` VALUES (335, 102, 3, 0, 44);
INSERT INTO `order_item` VALUES (336, 102, 5, 0, 41);
INSERT INTO `order_item` VALUES (337, 103, 2, 0, 2);
INSERT INTO `order_item` VALUES (338, 103, 4, 0, 25);
INSERT INTO `order_item` VALUES (339, 103, 3, 0, 44);
INSERT INTO `order_item` VALUES (340, 103, 5, 0, 41);
INSERT INTO `order_item` VALUES (341, 104, 2, 0, 2);
INSERT INTO `order_item` VALUES (342, 104, 4, 0, 25);
INSERT INTO `order_item` VALUES (343, 104, 3, 0, 44);
INSERT INTO `order_item` VALUES (344, 104, 5, 0, 41);
INSERT INTO `order_item` VALUES (345, 105, 2, 0, 2);
INSERT INTO `order_item` VALUES (346, 105, 4, 0, 25);
INSERT INTO `order_item` VALUES (347, 105, 3, 0, 44);
INSERT INTO `order_item` VALUES (348, 105, 5, 0, 41);
INSERT INTO `order_item` VALUES (349, 106, 2, 0, 2);
INSERT INTO `order_item` VALUES (350, 106, 4, 0, 25);
INSERT INTO `order_item` VALUES (351, 106, 3, 0, 44);
INSERT INTO `order_item` VALUES (352, 106, 5, 0, 41);
INSERT INTO `order_item` VALUES (353, 107, 2, 0, 2);
INSERT INTO `order_item` VALUES (354, 107, 4, 0, 25);
INSERT INTO `order_item` VALUES (355, 107, 3, 0, 44);
INSERT INTO `order_item` VALUES (356, 107, 5, 0, 41);
INSERT INTO `order_item` VALUES (357, 108, 2, 0, 2);
INSERT INTO `order_item` VALUES (358, 108, 4, 0, 25);
INSERT INTO `order_item` VALUES (359, 108, 3, 0, 44);
INSERT INTO `order_item` VALUES (360, 108, 5, 0, 41);
INSERT INTO `order_item` VALUES (361, 109, 2, 0, 2);
INSERT INTO `order_item` VALUES (362, 109, 4, 0, 25);
INSERT INTO `order_item` VALUES (363, 109, 3, 0, 44);
INSERT INTO `order_item` VALUES (364, 109, 5, 0, 41);
INSERT INTO `order_item` VALUES (365, 110, 2, 0, 2);
INSERT INTO `order_item` VALUES (366, 110, 4, 0, 25);
INSERT INTO `order_item` VALUES (367, 110, 3, 0, 44);
INSERT INTO `order_item` VALUES (368, 110, 5, 0, 41);
INSERT INTO `order_item` VALUES (369, 111, 2, 0, 2);
INSERT INTO `order_item` VALUES (370, 111, 4, 0, 25);
INSERT INTO `order_item` VALUES (371, 111, 3, 0, 44);
INSERT INTO `order_item` VALUES (372, 111, 5, 0, 41);
INSERT INTO `order_item` VALUES (373, 112, 2, 0, 2);
INSERT INTO `order_item` VALUES (374, 112, 4, 0, 25);
INSERT INTO `order_item` VALUES (375, 112, 3, 0, 44);
INSERT INTO `order_item` VALUES (376, 112, 5, 0, 41);
INSERT INTO `order_item` VALUES (377, 113, 2, 0, 2);
INSERT INTO `order_item` VALUES (378, 113, 4, 0, 25);
INSERT INTO `order_item` VALUES (379, 113, 3, 0, 44);
INSERT INTO `order_item` VALUES (380, 113, 5, 0, 41);
INSERT INTO `order_item` VALUES (381, 114, 2, 0, 2);
INSERT INTO `order_item` VALUES (382, 114, 4, 0, 25);
INSERT INTO `order_item` VALUES (383, 114, 3, 0, 44);
INSERT INTO `order_item` VALUES (384, 114, 5, 0, 41);
INSERT INTO `order_item` VALUES (385, 115, 2, 0, 2);
INSERT INTO `order_item` VALUES (386, 115, 4, 0, 25);
INSERT INTO `order_item` VALUES (387, 115, 3, 0, 44);
INSERT INTO `order_item` VALUES (388, 115, 5, 0, 41);
INSERT INTO `order_item` VALUES (389, 116, 2, 0, 2);
INSERT INTO `order_item` VALUES (390, 116, 4, 0, 25);
INSERT INTO `order_item` VALUES (391, 116, 3, 0, 44);
INSERT INTO `order_item` VALUES (392, 116, 5, 0, 41);
INSERT INTO `order_item` VALUES (393, 117, 2, 0, 2);
INSERT INTO `order_item` VALUES (394, 117, 4, 0, 25);
INSERT INTO `order_item` VALUES (395, 117, 3, 0, 44);
INSERT INTO `order_item` VALUES (396, 117, 5, 0, 41);
INSERT INTO `order_item` VALUES (397, 118, 2, 0, 2);
INSERT INTO `order_item` VALUES (398, 118, 4, 0, 25);
INSERT INTO `order_item` VALUES (399, 118, 3, 0, 44);
INSERT INTO `order_item` VALUES (400, 118, 5, 0, 41);
INSERT INTO `order_item` VALUES (401, 119, 1, 5, 1111);
INSERT INTO `order_item` VALUES (402, 120, 2, 1, 2);
INSERT INTO `order_item` VALUES (403, 120, 4, 1, 25);
INSERT INTO `order_item` VALUES (404, 120, 3, 1, 44);
INSERT INTO `order_item` VALUES (405, 120, 5, 10, 41);
INSERT INTO `order_item` VALUES (406, 121, 2, 3, 2);
INSERT INTO `order_item` VALUES (407, 124, 4, 1, 25);
INSERT INTO `order_item` VALUES (408, 125, 2, 1, 2);
INSERT INTO `order_item` VALUES (409, 126, 1, 1, 1111);
INSERT INTO `order_item` VALUES (410, 127, 1, 1, 1111);
INSERT INTO `order_item` VALUES (411, 128, 14, 1, 7);
INSERT INTO `order_item` VALUES (412, 129, 13, 1, 666);
INSERT INTO `order_item` VALUES (413, 130, 14, 1, 7);
INSERT INTO `order_item` VALUES (414, 131, 14, 1, 7);

-- ----------------------------
-- Table structure for table
-- ----------------------------
DROP TABLE IF EXISTS `table`;
CREATE TABLE `table`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `register_time` int(11) NULL DEFAULT NULL,
  `uid` int(11) NULL DEFAULT NULL,
  `img_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `name`(`name` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 30034 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of table
-- ----------------------------
INSERT INTO `table` VALUES (1, '琴韵阁', '琴韵阁，取意于古琴之雅韵，传承千年文化精髓。步入此间，仿佛置身于高山流水之间，聆听着古琴的悠扬之声，感受着古人的风雅与智慧。墙上挂有名家字画，每一幅都是精挑细选，与琴韵相得益彰。在这里，美食与艺术交融，为宾客带来一场视听与味觉的双重盛宴。', '空闲', -1, -1, 'https://s2.loli.net/2024/03/29/zKiILVnODeEb8YR.jpg');
INSERT INTO `table` VALUES (2, '梅兰竹菊', '梅兰竹菊，四君子也，代表着高洁、坚韧、谦逊和纯洁的品质。此包间以四季花卉为设计灵感，墙面装饰以精美的梅花、兰花、竹叶、菊花图案，营造出一种高雅脱俗的用餐环境，让宾客在享受中华美食的同时，也能感受到中华文化的深厚内涵。', '已占用', 1714744323, 32, 'https://s2.loli.net/2024/03/29/PIKim7HbFfXOuWy.webp');
INSERT INTO `table` VALUES (7, '龙吟凤哕', '取自古代诗词中的龙凤意象，寓意吉祥富贵，包间内装饰雍容华贵，透露出浓厚的皇家气派，是举办庆典宴会、彰显身份尊荣的理想之选。', '空闲', -1, -1, 'https://s2.loli.net/2024/03/29/gIljJsh2oPkdyAX.webp');
INSERT INTO `table` VALUES (8, '翠竹轩', '翠竹轩，雅致清幽，竹影婆娑映窗纱，宾客品茗论诗画，尽享静谧时光。', '空闲', 1711790781, 38, 'https://s2.loli.net/2024/03/29/jUJcZh6DnMy1xYV.png');
INSERT INTO `table` VALUES (9, '132465', '长文本测试长文本测试长文本测试长文本测试长文本测试长文本测试长文本测试长文本测试长文本测试长文本测试长文本测试长文本测试长文本测试长文本测试长文本测试长文本测试长文本测试长文本测试长文本测试长文本测试长文本测试长文本测试长文本测试长文本测试', '空闲', -1, -1, NULL);
INSERT INTO `table` VALUES (19, '啊哈哈哈哈哈哈，鸡汤来喽', '   诶，都，都 都看我干什么呀。\n          喝呀 喝呀 喝，快，快，趁热喝，嘿，趁热喝呀！', '空闲', -1, -1, 'https://pic4.zhimg.com/80/v2-59a2b0dd82e9cb4f27381db8560f958b_1440w.jpg');
INSERT INTO `table` VALUES (30, '四饭', '好用实用耐用', '空闲', -1, -1, 'https://bkbx65.gdut.edu.cn/__local/4/3A/F2/47229E6AFEBF7AE2C9B65B65C78_EA88DD76_55C45.png');
INSERT INTO `table` VALUES (31, '341312', '222133', '已占用', -1, -1, NULL);
INSERT INTO `table` VALUES (33, '1712030249190', '1712030249190', '空闲', -1, -1, NULL);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `role` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 30044 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (25, '441597', 'd78ac21cd7dabfec1332a8c0f4a84daa', 'user');
INSERT INTO `user` VALUES (26, '338657', '253c03d309fe7f6efa18db0720a708e8', 'user');
INSERT INTO `user` VALUES (27, '671566', '2effdf20a4aa1a7da12e1bc56770e237', 'user');
INSERT INTO `user` VALUES (28, '947787', 'ddfbdef7a3df2bff9d17afda05c812c7', 'user');
INSERT INTO `user` VALUES (29, '519817', '8c9771755298546270fb822769f102e1', 'user');
INSERT INTO `user` VALUES (30, '1', '5afd647e07458c83510b1cf9e9206b4e', 'admin');
INSERT INTO `user` VALUES (31, '555177', '872e6a7253deb9aae5805b089ea33450', 'user');
INSERT INTO `user` VALUES (32, '123', '874f32f8e916d95d78d25b4204e3877c', 'user');
INSERT INTO `user` VALUES (33, 'q', 'a979c357a8ad79e757698925f5c43881', 'user');
INSERT INTO `user` VALUES (34, '', '706eac96e641a6292ba5d06f20468074', 'user');
INSERT INTO `user` VALUES (35, '是谁', '4d334b3c063523c183b186ce8ca4e3e6', 'user');
INSERT INTO `user` VALUES (36, '2', 'a975669658a7f261b61bbe49f3ef882b', 'user');
INSERT INTO `user` VALUES (37, '3', 'b04543040b113aee5cc62904b5137ad9', 'user');
INSERT INTO `user` VALUES (38, '4', '5dfebb22939b2f524f40dd607321d8bb', 'user');
INSERT INTO `user` VALUES (39, '5', '7b150b5e3d2e6f7361bffbe5dadd907a', 'user');
INSERT INTO `user` VALUES (40, '6', '4b6afade40cf3b62095c381666c9de19', 'user');
INSERT INTO `user` VALUES (41, 'abc', '874f32f8e916d95d78d25b4204e3877c', 'user');
INSERT INTO `user` VALUES (42, 'suy', 'b028687664a2bb4ad6e5e833d9caa969', 'admin');
INSERT INTO `user` VALUES (43, 'admin', 'b028687664a2bb4ad6e5e833d9caa969', 'admin');

SET FOREIGN_KEY_CHECKS = 1;
